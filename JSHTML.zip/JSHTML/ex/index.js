const form = document.querySelector('#formulario');

form.addEventListener('submit', function (e){
 e.preventDefault();
 setResultado("Ola mundo")
});

function setResultado(msg){
    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = 'qualquer coisa';
    const p = document.createElement("p");
    p.innerHTML = 'Qualquer coisa';
    resultado.appendChild(p);
}